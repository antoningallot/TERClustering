class Point {
    
    private:

    float x;
    float y;

    public:
    
    Point(float abs, float ord);
};