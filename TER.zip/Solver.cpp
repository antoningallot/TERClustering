class Solver {
    
}